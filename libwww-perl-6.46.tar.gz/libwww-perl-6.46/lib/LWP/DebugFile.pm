package LWP::DebugFile;

our $VERSION = '6.46';

# legacy stub

1;
