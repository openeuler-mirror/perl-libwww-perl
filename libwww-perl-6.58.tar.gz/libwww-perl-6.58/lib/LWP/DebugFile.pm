package LWP::DebugFile;

our $VERSION = '6.58';

# legacy stub

1;
