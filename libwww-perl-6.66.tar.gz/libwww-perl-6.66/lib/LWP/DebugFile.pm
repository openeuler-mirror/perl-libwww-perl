package LWP::DebugFile;

our $VERSION = '6.66';

# legacy stub

1;
